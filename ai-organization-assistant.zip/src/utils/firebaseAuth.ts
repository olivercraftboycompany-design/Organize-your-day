// Firebase and Google Workspace Auth Manager
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from 'firebase/auth';

// Default stub configuration to let the application compile even if backend provisioning has regional/location errors
const DEFAULT_FALLBACK_CONFIG = {
  apiKey: "AIzaSyFakeKeyPlaceholderForWorkspaceAppletDemoOnly",
  authDomain: "workspace-demo-app.firebaseapp.com",
  projectId: "workspace-demo-app",
  storageBucket: "workspace-demo-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

let appInstance: any = null;
let authInstance: any = null;
let providerInstance: GoogleAuthProvider | null = null;
let isDemoEnabled = true;

// Define default mocks for User when in Demo mode
export interface DemoUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  emailVerified: boolean;
}

const MOCK_USER: DemoUser = {
  uid: "demo_executive_user",
  email: "olivercraftboycompany@gmail.com",
  displayName: "Oliver Craft",
  photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
  emailVerified: true
};

// Try initializing Firebase Auth
try {
  // Since we don't have direct configuration file, we default to fallback or look at standard envs
  const config = DEFAULT_FALLBACK_CONFIG;
  
  if (getApps().length === 0) {
    appInstance = initializeApp(config);
  } else {
    appInstance = getApp();
  }
  
  authInstance = getAuth(appInstance);
  providerInstance = new GoogleAuthProvider();
  
  // Set up required Google Workspace OAuth scopes
  const requiredScopes = [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/gmail.modify',
    'https://www.googleapis.com/auth/gmail.compose',
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/documents',
    'https://www.googleapis.com/auth/presentations',
    'https://www.googleapis.com/auth/tasks',
    'https://www.googleapis.com/auth/chat.spaces.readonly',
    'https://www.googleapis.com/auth/chat.messages.create',
    'https://www.googleapis.com/auth/keep',
    'https://www.googleapis.com/auth/meetings.space.created',
    'https://www.googleapis.com/auth/contacts'
  ];
  
  requiredScopes.forEach(scope => {
    providerInstance?.addScope(scope);
  });
  
  // If we loaded successfully, we can enable active Workspace if requested
  isDemoEnabled = true; // Stay in safe simulation/hybrid sandbox by default
} catch (e) {
  console.warn("Skipping standard Firebase initialization, using local state engine: ", e);
  isDemoEnabled = true;
}

let cachedAccessToken: string | null = null;
let cachedUser: any = null;
let authListeners: Array<(user: any, token: string | null) => void> = [];

// Broadcast changes
const notifyListeners = () => {
  authListeners.forEach(cb => cb(cachedUser, cachedAccessToken));
};

export const initAuth = (
  onAuthSuccess?: (user: any, token: string) => void,
  onAuthFailure?: () => void
) => {
  // In demo modal, we auto-authenticate user with simulation profile
  if (isDemoEnabled) {
    setTimeout(() => {
      cachedUser = MOCK_USER;
      cachedAccessToken = "simulated_oauth2_authorization_token_workspace_unlimited";
      if (onAuthSuccess) onAuthSuccess(cachedUser, cachedAccessToken);
      notifyListeners();
    }, 100);
    
    return () => {};
  }

  // Real auth subscription
  if (!authInstance) {
    if (onAuthFailure) onAuthFailure();
    return () => {};
  }

  return onAuthStateChanged(authInstance, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        cachedUser = user;
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
        notifyListeners();
      } else {
        // Clear state if no token yet
        cachedUser = null;
        if (onAuthFailure) onAuthFailure();
        notifyListeners();
      }
    } else {
      cachedUser = null;
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
      notifyListeners();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: any; accessToken: string } | null> => {
  if (isDemoEnabled) {
    cachedUser = MOCK_USER;
    cachedAccessToken = "simulated_oauth2_authorization_token_workspace_unlimited";
    notifyListeners();
    return { user: cachedUser, accessToken: cachedAccessToken };
  }

  if (!authInstance || !providerInstance) {
    throw new Error('Firebase Auth is not initialized or configured.');
  }

  try {
    const result = await signInWithPopup(authInstance, providerInstance);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to retrieve Google OAuth access token.');
    }
    cachedAccessToken = credential.accessToken;
    cachedUser = result.user;
    notifyListeners();
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in error: ', error);
    throw error;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logout = async () => {
  cachedAccessToken = null;
  cachedUser = null;
  notifyListeners();
  if (authInstance) {
    await signOut(authInstance);
  }
};

export const subscribeToAuth = (callback: (user: any, token: string | null) => void) => {
  authListeners.push(callback);
  callback(cachedUser, cachedAccessToken);
  return () => {
    authListeners = authListeners.filter(cb => cb !== callback);
  };
};

export const getIsDemoMode = () => {
  return isDemoEnabled;
};

export const toggleIsDemoMode = (val: boolean) => {
  isDemoEnabled = val;
  if (isDemoEnabled) {
    cachedUser = MOCK_USER;
    cachedAccessToken = "simulated_oauth2_authorization_token_workspace_unlimited";
  } else {
    cachedUser = null;
    cachedAccessToken = null;
  }
  notifyListeners();
};
