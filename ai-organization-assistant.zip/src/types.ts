export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface WorkspaceAction {
  id: string;
  type: 'calendar_create' | 'calendar_delete' | 'gmail_send' | 'drive_create_file' | 'drive_delete_file' | 'tasks_create' | 'tasks_update' | 'keep_create' | 'keep_delete' | 'sheets_append' | 'contacts_create' | 'chat_send_message';
  description: string;
  status: 'pending' | 'success' | 'cancelled' | 'failed';
  params: any;
}

export interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  startTime: string;
  endTime: string;
  attendees?: string[];
  meetLink?: string;
  creator?: string;
}

export interface GmailMessage {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  timestamp: string;
  folder: 'inbox' | 'sent' | 'draft';
  isRead: boolean;
}

export interface DriveFile {
  id: string;
  title: string;
  type: 'document' | 'spreadsheet' | 'presentation' | 'file';
  size: string;
  modifiedTime: string;
  content: string;
}

export interface GoogleTask {
  id: string;
  title: string;
  notes?: string;
  dueDate?: string;
  completed: boolean;
}

export interface KeepNote {
  id: string;
  title: string;
  content: string;
  color: string;
  updatedAt: string;
}

export interface GoogleContact {
  id: string;
  givenName: string;
  familyName: string;
  emails: string[];
  phones: string[];
}

export interface ChatMessage {
  id: string;
  spaceId: string;
  sender: string;
  message: string;
  timestamp: string;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  category: 'calendar' | 'gmail' | 'drive' | 'tasks' | 'keep' | 'contacts' | 'chat' | 'system';
  message: string;
  type: 'info' | 'success' | 'warning';
}
