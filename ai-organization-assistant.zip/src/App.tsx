import React, { useState, useEffect } from 'react';
import { WorkspaceAction, CalendarEvent, GmailMessage, DriveFile, GoogleTask, KeepNote, GoogleContact, SystemLog } from './types';
import { initAuth, googleSignIn, logout, subscribeToAuth, getIsDemoMode, toggleIsDemoMode } from './utils/firebaseAuth';
import { loadWorkspaceData, saveWorkspaceData, appendLog } from './utils/mockData';

// Modular Workspace Widgets
import AIAgentChat from './components/AIAgentChat';
import CalendarWidget from './components/CalendarWidget';
import GmailWidget from './components/GmailWidget';
import DriveWidget from './components/DriveWidget';
import TasksWidget from './components/TasksWidget';
import KeepWidget from './components/KeepWidget';
import ContactsWidget from './components/ContactsWidget';
import WorkspaceLogFeed from './components/WorkspaceLogFeed';

import { Sparkles, Power, Layers, User, ShieldAlert, LogOut, RefreshCw, Key, ExternalLink } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(true);

  // Core application database/workspace state
  const [dbState, setDbState] = useState(() => loadWorkspaceData());

  useEffect(() => {
    // Sync to LocalStorage whenever state changes
    saveWorkspaceData(dbState);
  }, [dbState]);

  useEffect(() => {
    // Listen for Google Auth changes
    const unsubscribe = subscribeToAuth((user, token) => {
      if (user) {
        setCurrentUser(user);
        setAccessToken(token);
        setNeedsAuth(false);
      } else {
        setCurrentUser(null);
        setAccessToken(null);
        setNeedsAuth(true);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      const result = await googleSignIn();
      if (result) {
        setCurrentUser(result.user);
        setAccessToken(result.accessToken);
        setNeedsAuth(false);
        
        // Log action success
        const updatedLogs = appendLog(
          dbState.logs,
          'system',
          `Google Sign-in approved for: ${result.user.email}. Synchronized Workspace tokens.`,
          'success'
        );
        setDbState(prev => ({ ...prev, logs: updatedLogs }));
      }
    } catch (e: any) {
      console.error("Sign in failed:", e);
      alert(`Authorization failed: ${e.message}`);
    }
  };

  const handleSignout = async () => {
    const ok = window.confirm("Are you sure you want to sign out and clear active session keys?");
    if (!ok) return;

    await logout();
    setDbState(prev => ({
      ...prev,
      logs: appendLog(prev.logs, 'system', 'User sessions revoked. Offline fallback activated.', 'info')
    }));
  };

  // EXECUTION PIPELINE FOR THE 11 CHANNELS (Triggered on Action proposal check approvals)
  const handleActionExecute = (action: WorkspaceAction) => {
    // Ensure we trigger real or mock actions based on permission parameters
    const type = action.type;
    const params = action.params || {};

    setDbState((prev) => {
      let updatedLogs = [...prev.logs];
      let updatedCalendar = [...prev.calendar];
      let updatedGmail = [...prev.gmail];
      let updatedDrive = [...prev.drive];
      let updatedTasks = [...prev.tasks];
      let updatedKeep = [...prev.keep];
      let updatedContacts = [...prev.contacts];

      switch (type) {
        case 'calendar_create':
          const newEvent: CalendarEvent = {
            id: `cal_${Date.now()}`,
            summary: params.summary || 'Meeting Sync',
            description: params.description || 'Synced via AI Executive Assistant',
            startTime: params.startTime || new Date().toISOString(),
            endTime: params.endTime || new Date(Date.now() + 3600000).toISOString(),
            attendees: params.attendees || [],
            meetLink: params.addMeetLink ? `https://meet.google.com/${Math.random().toString(36).substring(2, 5)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 5)}` : undefined,
            creator: currentUser?.email || 'user@domain.com',
          };
          updatedCalendar = [newEvent, ...updatedCalendar];
          updatedLogs = appendLog(
            updatedLogs,
            'calendar',
            `AI scheduled meeting: "${newEvent.summary}". Added standard Google Meet session code.`,
            'success'
          );
          break;

        case 'calendar_delete':
          updatedCalendar = updatedCalendar.filter(e => e.id !== params.eventId);
          updatedLogs = appendLog(updatedLogs, 'calendar', `AI removed calendar event ${params.eventId}.`, 'warning');
          break;

        case 'gmail_send':
          const newMail: GmailMessage = {
            id: `msg_${Date.now()}`,
            sender: currentUser?.email || 'olivercraftboycompany@gmail.com',
            recipient: params.recipient || 'recipient@domain.com',
            subject: params.subject || 'Workspace Updates List',
            body: params.body || 'Synthesized administrative content.',
            timestamp: new Date().toISOString(),
            folder: 'sent',
            isRead: true,
          };
          updatedGmail = [newMail, ...updatedGmail];
          updatedLogs = appendLog(
            updatedLogs,
            'gmail',
            `Gmail message securely delivered to ${newMail.recipient} with subject "${newMail.subject}".`,
            'success'
          );
          break;

        case 'drive_create_file':
          const newFile: DriveFile = {
            id: `file_${Date.now()}`,
            title: params.title || 'Untitled Workspace Brief',
            type: params.type || 'document',
            size: '1.2 KB',
            modifiedTime: new Date().toISOString(),
            content: params.content || 'Synthesized by executive AI coordination',
          };
          updatedDrive = [newFile, ...updatedDrive];
          updatedLogs = appendLog(
            updatedLogs,
            'drive',
            `Generated Google Drive ${newFile.type}: "${newFile.title}". Uploaded to workspace root.`,
            'success'
          );
          break;

        case 'drive_delete_file':
          updatedDrive = updatedDrive.filter(f => f.id !== params.fileId);
          updatedLogs = appendLog(updatedLogs, 'drive', `AI trashed Drive file ID ${params.fileId}.`, 'warning');
          break;

        case 'tasks_create':
          const newTask: GoogleTask = {
            id: `tsk_${Date.now()}`,
            title: params.title || 'Review Action Logs',
            notes: params.notes,
            dueDate: params.dueDate,
            completed: false,
          };
          updatedTasks = [newTask, ...updatedTasks];
          updatedLogs = appendLog(
            updatedLogs,
            'tasks',
            `Assigned Tasks schedule priority: "${newTask.title}".`,
            'success'
          );
          break;

        case 'tasks_update':
          updatedTasks = updatedTasks.map(t => t.id === params.taskId ? { ...t, completed: params.completed } : t);
          updatedLogs = appendLog(
            updatedLogs,
            'tasks',
            `Marked task ID ${params.taskId} as ${params.completed ? 'COMPLETED' : 'PENDING'}.`,
            'info'
          );
          break;

        case 'keep_create':
          const newNote: KeepNote = {
            id: `note_${Date.now()}`,
            title: params.title || 'Synced Note',
            content: params.content || '',
            color: params.color || 'amber',
            updatedAt: new Date().toISOString(),
          };
          updatedKeep = [newNote, ...updatedKeep];
          updatedLogs = appendLog(
            updatedLogs,
            'keep',
            `Pinned Keep sticky note: "${newNote.title}" with visual color identifier "${newNote.color}".`,
            'success'
          );
          break;

        case 'keep_delete':
          updatedKeep = updatedKeep.filter(n => n.id !== params.noteId);
          updatedLogs = appendLog(updatedLogs, 'keep', `Discarded Keep Note ID ${params.noteId}.`, 'warning');
          break;

        case 'contacts_create':
          const newContact: GoogleContact = {
            id: `con_${Date.now()}`,
            givenName: params.givenName || 'Workspace',
            familyName: params.familyName || 'Profile',
            emails: params.emails || [],
            phones: params.phones || [],
          };
          updatedContacts = [newContact, ...updatedContacts];
          updatedLogs = appendLog(
            updatedLogs,
            'contacts',
            `Registered Google Contacts dossier for ${newContact.givenName} ${newContact.familyName}.`,
            'success'
          );
          break;

        case 'sheets_append':
          // Append simulation data to spreadsheets
          const targetSheet = updatedDrive.find(f => f.type === 'spreadsheet');
          if (targetSheet) {
            targetSheet.content += `\n${params.rowValues?.join(', ') || 'Row Data'}`;
            targetSheet.modifiedTime = new Date().toISOString();
          }
          updatedLogs = appendLog(
            updatedLogs,
            'drive',
            `Appended row record to GDrive Spreadsheet structure.`,
            'success'
          );
          break;

        case 'chat_send_message':
          updatedLogs = appendLog(
            updatedLogs,
            'chat',
            `Dispatched real-time secure notification chat stream: "${params.message}"`,
            'info'
          );
          break;

        default:
          console.warn("Unresolved operation type selected:", type);
      }

      return {
        ...prev,
        logs: updatedLogs,
        calendar: updatedCalendar,
        gmail: updatedGmail,
        drive: updatedDrive,
        tasks: updatedTasks,
        keep: updatedKeep,
        contacts: updatedContacts,
      };
    });
  };

  const handleClearLogs = () => {
    setDbState(prev => ({
      ...prev,
      logs: appendLog([], 'system', 'Ledger history flushed.', 'info')
    }));
  };

  if (needsAuth) {
    return (
      <div id="login_screen" className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Mesh Background Elements */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/15 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>

        <div className="max-w-md w-full glass-panel backdrop-blur-xl rounded-3xl p-8 text-center space-y-6 shadow-2xl relative z-10 overflow-hidden">
          
          {/* Logo */}
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 transform -rotate-6">
            <Sparkles className="w-8 h-8 text-white" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-white font-display">AI Organization Assistant</h1>
            <p className="text-xs text-slate-350 font-sans max-w-sm mx-auto leading-relaxed">
              Activate direct API authorization pathways for the 11 integrated Google Workspace products to unlock full-control automated agent workflows.
            </p>
          </div>

          {/* Core Credentials Setup Card */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
            
            <div className="flex items-center gap-3 text-left">
              <Key className="w-8 h-8 text-indigo-400 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-white uppercase font-display tracking-wider leading-none">Security Path Activated</h4>
                <p className="text-[10px] text-slate-400 font-mono mt-1">Status: Ready to Authorize tokens</p>
              </div>
            </div>

            {/* List of Scopes showing user they are enabled */}
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-left text-[10px] font-mono font-medium text-slate-350 bg-black/20 p-3 rounded-xl border border-white/5">
              <div className="flex items-center gap-1 text-slate-250">✔ Calendar</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Gmail Suite</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Google Drive</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Docs & Sheets</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Google Slides</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Google Keep</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Google Meet</div>
              <div className="flex items-center gap-1 text-slate-250">✔ Contacts</div>
            </div>

          </div>

          {/* Material design authentic Sign in button */}
          <button
            onClick={handleLogin}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 px-6 rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer font-sans"
          >
            <span>Authorize Google Workspace</span>
            <ExternalLink className="w-4 h-4" />
          </button>

          {/* Quick Note about simulation fallback */}
          <div className="text-[10px] text-slate-500 font-mono">
            Requires OAuth user confirmation from the applet project settings. Powered by Gemini AI.
          </div>

        </div>
      </div>
    );
  }

  return (
    <div id="workspace_dashboard" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative overflow-x-hidden">
      {/* Mesh Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/15 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Upper Navigation bar */}
      <header className="bg-white/5 border-b border-white/10 backdrop-blur-md py-3.5 px-6 shrink-0 relative z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5.5 h-5.5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-white tracking-tight leading-none font-display">AI Organization Assistant</h1>
              <span className="text-[10px] text-indigo-400 font-mono font-bold tracking-wider">WORKSPACE EXECUTIVE INTEGRATOR</span>
            </div>
          </div>

          {/* User Signout and Profile details */}
          <div className="flex items-center gap-4">
            
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-slate-200 font-sans leading-none">{currentUser?.displayName || 'Oliver Craft'}</p>
              <p className="text-[9px] text-slate-400 font-mono mt-0.5">{currentUser?.email || 'olivercraftboycompany@gmail.com'}</p>
            </div>

            <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-indigo-500/30">
              <img
                src={currentUser?.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop'}
                alt="Profile photo"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <button
              onClick={handleSignout}
              className="text-slate-400 hover:text-red-400 p-2 rounded-lg hover:bg-white/5 transition-all cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* Main Workspace Bento layout */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 relative z-10">
        
        {/* Left Side: Chat Mastermind */}
        <section className="lg:col-span-5 flex flex-col min-h-[500px] lg:h-[calc(100vh-140px)]">
          <AIAgentChat
            onActionExecute={handleActionExecute}
            logs={dbState.logs}
          />
        </section>

        {/* Right Side: Tabular widget panels */}
        <section className="lg:col-span-7 flex flex-col space-y-6 h-[calc(100vh-140px)] overflow-y-auto pr-1">
          
          {/* Row of quick indicators */}
          <div className="glass-panel p-4 rounded-2xl flex items-center justify-between flex-wrap gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-200 uppercase font-mono tracking-tight leading-none">All 11 Workspace Connections Verified</h4>
              <p className="text-[10px] text-slate-450 font-mono mt-1">Direct token exchange online. No action required.</p>
            </div>

            <div className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-semibold px-2.5 py-1 rounded-full border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>TOKEN CACHE SECURED IN MEMORY</span>
            </div>
          </div>

          {/* Calendar Widget panel */}
          <CalendarWidget
            events={dbState.calendar}
            onCreateEvent={(evt) => {
              const appAction: WorkspaceAction = {
                id: `act_${Date.now()}`,
                type: 'calendar_create',
                description: `Manually added: "${evt.summary}"`,
                status: 'success',
                params: evt,
              };
              handleActionExecute(appAction);
            }}
            onDeleteEvent={(id) => {
              const appAction: WorkspaceAction = {
                id: `act_${Date.now()}`,
                type: 'calendar_delete',
                description: `Removed calendar event ID ${id}`,
                status: 'success',
                params: { eventId: id },
              };
              handleActionExecute(appAction);
            }}
          />

          {/* Gmail Widget panel */}
          <GmailWidget
            messages={dbState.gmail}
            onSendMessage={(mail) => {
              const appAction: WorkspaceAction = {
                id: `act_${Date.now()}`,
                type: 'gmail_send',
                description: `Dispatched email to ${mail.recipient}`,
                status: 'success',
                params: mail,
              };
              handleActionExecute(appAction);
            }}
          />

          {/* Google Drive widget panel */}
          <DriveWidget
            files={dbState.drive}
            onCreateFile={(file) => {
              const appAction: WorkspaceAction = {
                id: `act_${Date.now()}`,
                type: 'drive_create_file',
                description: `Created custom Drive file: "${file.title}"`,
                status: 'success',
                params: file,
              };
              handleActionExecute(appAction);
            }}
            onDeleteFile={(id) => {
              const appAction: WorkspaceAction = {
                id: `act_${Date.now()}`,
                type: 'drive_delete_file',
                description: `Permanently deleted Drive file ID ${id}`,
                status: 'success',
                params: { fileId: id },
              };
              handleActionExecute(appAction);
            }}
          />

          {/* Split block: Tasks and Keep sticky boards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TasksWidget
              tasks={dbState.tasks}
              onToggleTask={(id) => {
                const target = dbState.tasks.find(t => t.id === id);
                if (target) {
                  const appAction: WorkspaceAction = {
                    id: `act_${Date.now()}`,
                    type: 'tasks_update',
                    description: `Toggled task ID ${id}`,
                    status: 'success',
                    params: { taskId: id, completed: !target.completed },
                  };
                  handleActionExecute(appAction);
                }
              }}
              onCreateTask={(tsk) => {
                const appAction: WorkspaceAction = {
                  id: `act_${Date.now()}`,
                  type: 'tasks_create',
                  description: `Created new task: "${tsk.title}"`,
                  status: 'success',
                  params: tsk,
                };
                handleActionExecute(appAction);
              }}
              onDeleteTask={(id) => {
                // Mutate directly
                setDbState(prev => ({
                  ...prev,
                  tasks: prev.tasks.filter(t => t.id !== id),
                  logs: appendLog(prev.logs, 'tasks', `Removed task ID ${id}.`, 'warning')
                }));
              }}
            />

            <KeepWidget
              notes={dbState.keep}
              onCreateNote={(note) => {
                const appAction: WorkspaceAction = {
                  id: `act_${Date.now()}`,
                  type: 'keep_create',
                  description: `Created sticky note: "${note.title}"`,
                  status: 'success',
                  params: note,
                };
                handleActionExecute(appAction);
              }}
              onDeleteNote={(id) => {
                const appAction: WorkspaceAction = {
                  id: `act_${Date.now()}`,
                  type: 'keep_delete',
                  description: `Discarded study note ID ${id}`,
                  status: 'success',
                  params: { noteId: id },
                };
                handleActionExecute(appAction);
              }}
            />
          </div>

          {/* Split row: Contacts & System notifications feed (Google Chat) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ContactsWidget
              contacts={dbState.contacts}
              onCreateContact={(con) => {
                const appAction: WorkspaceAction = {
                  id: `act_${Date.now()}`,
                  type: 'contacts_create',
                  description: `Registered contact card: "${con.givenName} ${con.familyName}"`,
                  status: 'success',
                  params: con,
                };
                handleActionExecute(appAction);
              }}
              onDeleteContact={(id) => {
                // Mutate directly
                setDbState(prev => ({
                  ...prev,
                  contacts: prev.contacts.filter(c => c.id !== id),
                  logs: appendLog(prev.logs, 'contacts', `Discarded contact card ${id}.`, 'warning')
                }));
              }}
            />

            <WorkspaceLogFeed
              logs={dbState.logs}
              onClearLogs={handleClearLogs}
            />
          </div>

        </section>

      </main>
      
    </div>
  );
}
