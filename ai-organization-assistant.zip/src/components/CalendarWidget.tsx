import React, { useState } from 'react';
import { CalendarEvent } from '../types';
import { Calendar, Video, Clock, Users, Plus, Trash2, CalendarDays } from 'lucide-react';

interface CalendarWidgetProps {
  events: CalendarEvent[];
  onCreateEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  onDeleteEvent: (id: string) => void;
}

export default function CalendarWidget({ events, onCreateEvent, onDeleteEvent }: CalendarWidgetProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [summary, setSummary] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState(new Date(Date.now() + 3600000).toISOString().slice(0, 16));
  const [endTime, setEndTime] = useState(new Date(Date.now() + 7200000).toISOString().slice(0, 16));
  const [attendees, setAttendees] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!summary) return;

    onCreateEvent({
      summary,
      description,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      attendees: attendees ? attendees.split(',').map(a => a.trim()) : [],
      meetLink: `https://meet.google.com/${Math.random().toString(36).substring(2, 5)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 5)}`,
      creator: 'olivercraftboycompany@gmail.com',
    });

    // Reset Form
    setSummary('');
    setDescription('');
    setAttendees('');
    setShowAddForm(false);
  };

  return (
    <div className="glass-panel rounded-3xl p-5 space-y-4">
      
      {/* Title block */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <Calendar className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Google Calendar Agenda</h3>
            <p className="text-[10px] text-slate-450 font-mono">Syncing Primary Calendar</p>
          </div>
        </div>
 
        <button
          onClick={() => setShowAddForm(p => !p)}
          className="text-xs font-semibold bg-white/5 text-slate-200 border border-white/10 py-1.5 px-3 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Meeting</span>
        </button>
      </div>
 
      {/* Add form */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-3 font-sans">
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Title</label>
            <input
              type="text"
              required
              value={summary}
              onChange={e => setSummary(e.target.value)}
              placeholder="E.g., Board Mergers & Acquisitions Sync"
              className="w-full bg-slate-900/60 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
 
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Agenda / Description</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Outline meeting bullet points..."
              className="w-full bg-slate-900/60 border border-white/10 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 h-16 resize-none"
            />
          </div>
 
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Start Time</label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={e => setStartTime(e.target.value)}
                className="w-full bg-slate-900/60 border border-white/10 rounded-lg p-1.5 text-[11px] text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">End Time</label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={e => setEndTime(e.target.value)}
                className="w-full bg-slate-900/60 border border-white/10 rounded-lg p-1.5 text-[11px] text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>
 
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Attendees (Comma Separated Emails)</label>
            <input
              type="text"
              value={attendees}
              onChange={e => setAttendees(e.target.value)}
              placeholder="e.g. boss@venture.com, assistant@co`"
              className="w-full bg-slate-900/60 border border-white/10 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
 
          <div className="flex justify-end gap-2 text-xs pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium p-1.5 rounded-lg px-3 flex items-center gap-1 cursor-pointer shadow-md shadow-indigo-600/20"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Create with Google Meet</span>
            </button>
          </div>
        </form>
      )}
 
      {/* Agenda list */}
      <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
        {events.length === 0 ? (
          <div className="text-center py-8 bg-white/5 rounded-xl border border-dashed border-white/10 text-slate-400 flex flex-col items-center">
            <CalendarDays className="w-8 h-8 text-slate-600 mb-1" />
            <p className="text-xs p-1">No calendar events listed</p>
          </div>
        ) : (
          events.map((event) => {
            const startD = new Date(event.startTime);
            const dateStr = startD.toLocaleDateString([], { month: 'short', day: 'numeric' });
            const timeStr = startD.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
 
            return (
              <div
                key={event.id}
                className="p-3 border border-white/5 bg-white/5 rounded-xl hover:bg-white/10 transition-colors flex justify-between gap-3"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-white leading-none">{event.summary}</span>
                  </div>
                  
                  {event.description && (
                    <p className="text-[11px] text-slate-300 leading-relaxed max-w-[280px]">{event.description}</p>
                  )}
 
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-slate-400 font-mono font-medium">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {dateStr}, {timeStr}
                    </span>
                    {event.attendees && event.attendees.length > 0 && (
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-slate-400" />
                        {event.attendees.length} people
                      </span>
                    )}
                  </div>
 
                  {event.meetLink && (
                    <a
                      href={event.meetLink}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-1 flex items-center gap-1 bg-indigo-500/20 text-indigo-200 hover:bg-indigo-500/35 border border-indigo-500/20 text-[10px] p-1.5 px-2.5 rounded-md font-medium w-max font-mono leading-none"
                    >
                      <Video className="w-3 h-3 text-indigo-400" />
                      <span>Meet: {event.meetLink.replace('https://', '')}</span>
                    </a>
                  )}
                </div>
 
                <button
                  onClick={() => {
                    const confirmDel = window.confirm(`Remove event: "${event.summary}"?`);
                    if (confirmDel) onDeleteEvent(event.id);
                  }}
                  className="p-1 hover:text-red-400 text-slate-400 hover:bg-white/5 rounded transition-colors self-start cursor-pointer"
                  title="Remove meeting"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
