import React, { useState } from 'react';
import { GmailMessage } from '../types';
import { Mail, Search, Paperclip, Send, MailOpen, Compass, Inbox, ChevronRight } from 'lucide-react';

interface GmailWidgetProps {
  messages: GmailMessage[];
  onSendMessage: (msg: Omit<GmailMessage, 'id' | 'timestamp' | 'folder' | 'isRead'>) => void;
}

export default function GmailWidget({ messages, onSendMessage }: GmailWidgetProps) {
  const [activeFolder, setActiveFolder] = useState<'inbox' | 'sent'>('inbox');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMail, setSelectedMail] = useState<GmailMessage | null>(null);
  const [showCompose, setShowCompose] = useState(false);
  
  // Compose states
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  const filtered = messages
    .filter(m => m.folder === activeFolder)
    .filter(m => 
      m.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.body.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.sender.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const handleComposeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!to || !subject || !body) return;

    // Mutates
    onSendMessage({
      recipient: to,
      sender: 'olivercraftboycompany@gmail.com',
      subject,
      body,
    });

    setTo('');
    setSubject('');
    setBody('');
    setShowCompose(false);
  };

  return (
    <div className="glass-panel rounded-3xl p-5 space-y-4">
      
      {/* Widget banner */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <Mail className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Gmail Workspace</h3>
            <p className="text-[10px] text-slate-450 font-mono">olivercraftboycompany@gmail.com</p>
          </div>
        </div>

        <button
          onClick={() => setShowCompose(p => !p)}
          className="text-xs bg-indigo-600 border border-indigo-500 text-white font-medium py-1.5 px-3 rounded-lg hover:bg-indigo-500/80 transition-colors cursor-pointer shadow-md shadow-indigo-600/20"
        >
          Compose Message
        </button>
      </div>

      {/* Tabs list & search inline */}
      <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2">
        <div className="flex bg-black/20 border border-white/5 rounded-lg p-0.5 text-xs">
          <button
            onClick={() => { setActiveFolder('inbox'); setSelectedMail(null); }}
            className={`py-1 px-3.5 rounded-md font-medium cursor-pointer transition-colors ${
              activeFolder === 'inbox' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Inbox
          </button>
          <button
            onClick={() => { setActiveFolder('sent'); setSelectedMail(null); }}
            className={`py-1 px-3.5 rounded-md font-medium cursor-pointer transition-colors ${
              activeFolder === 'sent' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Sent Mail
          </button>
        </div>

        <div className="relative text-xs">
          <input
            type="text"
            placeholder="Search email threads..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="border border-white/10 bg-slate-900/60 rounded-lg pl-8 pr-2 py-1 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-[140px] md:w-[180px]"
          />
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
        </div>
      </div>

      {/* Compose overlay */}
      {showCompose && (
        <form onSubmit={handleComposeSubmit} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-3 font-sans">
          <div className="flex justify-between items-center pb-1 border-b border-white/10">
            <span className="text-xs font-semibold text-white">New Email Message</span>
            <button
              type="button"
              onClick={() => setShowCompose(false)}
              className="text-slate-400 hover:text-white text-xs cursor-pointer"
            >
              Cancel
            </button>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">To</label>
            <input
              type="email"
              required
              placeholder="recipient@domain.com"
              value={to}
              onChange={e => setTo(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-500 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">Subject</label>
            <input
              type="text"
              required
              placeholder="Workspace Update Briefing"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-500 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">Message Body</label>
            <textarea
              required
              placeholder="Compose your message corporate outline here..."
              value={body}
              onChange={e => setBody(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-500 rounded-lg p-2 text-xs focus:ring-1 focus:ring-indigo-500 h-28 resize-none font-sans"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <button type="button" className="text-slate-400 hover:text-white p-1 rounded cursor-pointer">
              <Paperclip className="w-4 h-4" />
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-1 px-3.5 rounded-lg flex items-center gap-1 text-xs cursor-pointer shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Message</span>
            </button>
          </div>
        </form>
      )}

      {/* Grid of emails and open panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Messages List col */}
        <div className="space-y-2 border-r border-white/5 pr-2 max-h-[300px] overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-slate-500 flex flex-col items-center">
              <Inbox className="w-8 h-8 text-slate-600 mb-1" />
              <p className="text-xs">No email messages found</p>
            </div>
          ) : (
            filtered.map((mail) => (
              <button
                key={mail.id}
                onClick={() => setSelectedMail(mail)}
                className={`w-full text-left p-2.5 rounded-xl border transition-colors flex justify-between gap-2 cursor-pointer ${
                  selectedMail?.id === mail.id 
                    ? 'border-indigo-500/30 bg-indigo-500/10' 
                    : 'border-white/5 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="space-y-1 overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-mono truncate mr-2">{mail.sender}</span>
                    <span className="text-[9px] text-slate-500 font-mono shrink-0">
                      {new Date(mail.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                  <h4 className="text-xs font-semibold text-slate-100 truncate leading-snug">{mail.subject}</h4>
                  <p className="text-[10px] text-slate-400 truncate font-sans">{mail.body}</p>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 self-center shrink-0" />
              </button>
            ))
          )}
        </div>

        {/* Message details panel */}
        <div className="bg-white/5 p-3 rounded-2xl border border-white/5 flex flex-col justify-between max-h-[300px] overflow-y-auto">
          {selectedMail ? (
            <div className="space-y-2 text-xs">
              <div className="border-b border-white/10 pb-2 space-y-1">
                <div className="flex flex-col gap-0.5 text-[10px] text-slate-400 font-mono">
                  <span>From: {selectedMail.sender}</span>
                  <span>To: {selectedMail.recipient}</span>
                </div>
                <h4 className="text-sm font-semibold text-white leading-snug">{selectedMail.subject}</h4>
                <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                  {new Date(selectedMail.timestamp).toLocaleString()}
                </div>
              </div>
              <p className="text-slate-300 leading-relaxed font-sans whitespace-pre-line text-[11px]">
                {selectedMail.body}
              </p>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500 flex flex-col items-center justify-center h-full">
              <MailOpen className="w-8 h-8 text-slate-600 mb-1.5" />
              <p className="text-xs">Select email thread to preview</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
