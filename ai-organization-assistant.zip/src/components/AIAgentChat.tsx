import React, { useState, useRef, useEffect } from 'react';
import { Message, WorkspaceAction } from '../types';
import { Sparkles, Send, BrainCircuit, ArrowRight, Check, X, ShieldAlert, Globe, Compass, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface AIAgentChatProps {
  onActionExecute: (action: WorkspaceAction) => void;
  logs: any[];
}

export default function AIAgentChat({ onActionExecute, logs }: AIAgentChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hello Oliver, I am your highkey robust AI Organization Assistant. I command full orchestration access across all 11 Google Workspace interfaces. How can I assist you with your Calendar, Mail, File generation, Tasks, Contacts, or Keep notes today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedModel, setSelectedModel] = useState('gemini-3.5-flash');
  const [useThinking, setUseThinking] = useState(false);
  const [useSearchGrounding, setUseSearchGrounding] = useState(false);
  const [useMapsGrounding, setUseMapsGrounding] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [proposals, setProposals] = useState<WorkspaceAction[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, proposals]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/agent/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMessage].map(m => ({ role: m.role, content: m.content })),
          selectedModel,
          useThinking,
          webGrounding: useSearchGrounding,
          localTime: new Date().toISOString(),
        }),
      });

      if (!response.ok) {
        throw new Error('Intelligence server connection faulted');
      }

      const data = await response.json();

      const assistantMessage: Message = {
        id: `ast_${Date.now()}`,
        role: 'assistant',
        content: data.text || "Command processed successfully.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, assistantMessage]);

      if (data.proposedActions && Array.isArray(data.proposedActions) && data.proposedActions.length > 0) {
        // Enlist new key actions as pending user approval
        const newActions: WorkspaceAction[] = data.proposedActions.map((act: any) => ({
          ...act,
          status: 'pending' as const,
        }));
        setProposals(prev => [...prev, ...newActions]);
      }

    } catch (err: any) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: "I encountered a communication fault compiling that workspace operation. Please ensure server host connections are online.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const approveProposal = (action: WorkspaceAction) => {
    // Notify app to append/mutate mock data securely
    onActionExecute({ ...action, status: 'success' });
    setProposals(prev => prev.filter(p => p.id !== action.id));
  };

  const rejectProposal = (action: WorkspaceAction) => {
    setProposals(prev => prev.filter(p => p.id !== action.id));
  };

  return (
    <div id="ai_chat_container" className="flex flex-col h-full glass-panel rounded-3xl overflow-hidden relative">
      
      {/* Top Header Controls */}
      <div className="bg-white/5 border-b border-white/10 p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Identity & Status */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
              <Sparkles className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white font-display">Executive System Core</h2>
              <div className="flex items-center gap-1.5 leading-none">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[10px] text-emerald-400 font-mono font-medium">FULL CONTROL ACTIVE</span>
              </div>
            </div>
          </div>

          {/* Prompt Model & Parameter Controls */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Model Selection */}
            <select
              value={selectedModel}
              onChange={(e) => {
                setSelectedModel(e.target.value);
                if (e.target.value.includes('pro')) {
                  setUseThinking(true);
                } else {
                  setUseThinking(false);
                }
              }}
              className="text-xs border border-white/15 bg-slate-900/80 rounded-md py-1 px-2 text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="gemini-3.5-flash">gemini-3.5-flash (General)</option>
              <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Complex)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast)</option>
            </select>

            {/* High Thinking switch (pro only or general) */}
            <button
              onClick={() => {
                setUseThinking(prev => {
                  if (!prev) {
                    setSelectedModel('gemini-3.1-pro-preview');
                  }
                  return !prev;
                });
              }}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium border cursor-pointer transition-colors ${
                useThinking
                  ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                  : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
              }`}
              title="Activate deeper planning and maximum intelligence on complex schedules"
            >
              <BrainCircuit className="w-3.5 h-3.5" />
              <span>Thinking: {useThinking ? 'HIGH' : 'OFF'}</span>
            </button>

            {/* Web Search Grounding */}
            <button
              onClick={() => setUseSearchGrounding(p => !p)}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium border cursor-pointer transition-colors ${
                useSearchGrounding
                  ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                  : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
              }`}
              title="Search Google live to ground your calendar and replies"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Search</span>
            </button>

            {/* Google Maps Grounding */}
            <button
              onClick={() => setUseMapsGrounding(p => !p)}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium border cursor-pointer transition-colors ${
                useMapsGrounding
                  ? 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                  : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
              }`}
              title="Ground locations, business details or map parameters"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Maps</span>
            </button>
          </div>

        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-md ${
                msg.role === 'user'
                  ? 'bg-indigo-600/30 text-white border border-indigo-500/20 rounded-br-none'
                  : 'bg-white/5 text-slate-200 border border-white/10 rounded-bl-none'
              }`}
            >
              <div className="font-medium text-[10px] opacity-70 mb-1 leading-none font-mono">
                {msg.role === 'user' ? 'Oliver Craft' : 'Executive Assistant'} • {msg.timestamp}
              </div>
              <p className="whitespace-pre-wrap leading-relaxed font-sans">{msg.content}</p>
            </div>
          </div>
        ))}

        {/* Loading Bubble */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/5 border border-white/10 rounded-2xl rounded-bl-none px-4 py-3 shadow-md text-slate-400 text-sm flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce"></span>
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.4s]"></span>
              <span className="text-xs font-mono font-medium tracking-tight text-slate-300">AI Agent drafting organizational adjustments...</span>
            </div>
          </div>
        )}

        {/* PROPOSED ACTION CARDS - Requires user consent before modifying data (Security Standard) */}
        {proposals.length > 0 && (
          <div className="border-t border-dashed border-white/15 pt-4 mt-2">
            <div className="flex items-center gap-1.5 text-amber-400 mb-2 font-semibold text-xs px-1">
              <ShieldAlert className="w-4.5 h-4.5" />
              <span>PENDING WORKSPACE MODIFICATION AGREEMENT</span>
            </div>
            
            <div className="space-y-3">
              {proposals.map((action) => (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={action.id}
                  className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="bg-amber-500/20 text-amber-300 text-[10px] font-semibold font-mono rounded px-1.5 py-0.5 w-max border border-amber-500/20">
                        ACTION: {action.type.toUpperCase()}
                      </div>
                      <p className="text-sm font-semibold text-slate-100 leading-snug">{action.description}</p>
                      
                      {/* Interactive block visual parameters */}
                      <div className="mt-2 bg-black/20 rounded-lg border border-white/5 p-2.5 space-y-1.5 font-mono text-[11px] text-slate-300">
                        {Object.entries(action.params || {}).map(([key, val]) => (
                          <div key={key} className="grid grid-cols-3 gap-1">
                            <span className="text-slate-400 font-medium">{key}:</span>
                            <span className="col-span-2 text-slate-200 break-words">
                              {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Agree / Deny controls */}
                    <div className="flex flex-col gap-1.5">
                      <button
                        onClick={() => approveProposal(action)}
                        className="rounded-lg p-2 bg-emerald-600 text-white hover:bg-emerald-500 shadow-md cursor-pointer transition-colors flex items-center justify-center"
                        title="Confirm and Permit execution on user account data"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => rejectProposal(action)}
                        className="rounded-lg p-2 bg-white/5 text-slate-350 hover:bg-white/10 cursor-pointer border border-white/10 transition-colors flex items-center justify-center"
                        title="Cancel proposal"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form area */}
      <form onSubmit={handleSend} className="p-3 border-t border-white/10 flex items-center gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="E.g., 'Schedule strategic meeting tomorrow at 3pm and draft a memo...'"
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500/50 transition-all font-sans"
        />
        <button
          type="submit"
          className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl py-3 px-4 shadow-lg shadow-indigo-600/20 font-medium text-sm cursor-pointer transition-colors flex items-center gap-1.5"
        >
          <span>Send</span>
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
}
