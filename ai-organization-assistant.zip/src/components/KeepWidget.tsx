import React, { useState } from 'react';
import { KeepNote } from '../types';
import { StickyNote, Plus, Trash2, Pin } from 'lucide-react';

interface KeepWidgetProps {
  notes: KeepNote[];
  onCreateNote: (note: Omit<KeepNote, 'id' | 'updatedAt'>) => void;
  onDeleteNote: (id: string) => void;
}

export default function KeepWidget({ notes, onCreateNote, onDeleteNote }: KeepWidgetProps) {
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState('amber');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onCreateNote({
      title: title || 'Untitled Note',
      content,
      color,
    });

    setTitle('');
    setContent('');
    setColor('amber');
    setShowForm(false);
  };

  const getColorClasses = (clr: string) => {
    switch (clr) {
      case 'emerald':
        return 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-100 shadow-sm shadow-emerald-950/20';
      case 'blue':
      case 'sky':
        return 'bg-sky-950/40 border border-sky-500/30 text-sky-100 shadow-sm shadow-sky-950/20';
      case 'rose':
      case 'red':
        return 'bg-rose-950/40 border border-rose-500/30 text-rose-100 shadow-sm shadow-rose-950/20';
      default:
        return 'bg-amber-950/40 border border-amber-500/30 text-amber-100 shadow-sm shadow-amber-950/20';
    }
  };

  return (
    <div className="glass-panel rounded-3xl p-4 space-y-4">
      
      {/* Title block */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <StickyNote className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Google Keep</h3>
            <p className="text-[10px] text-slate-450 font-mono">Synced Sticky Notes</p>
          </div>
        </div>

        <button
          onClick={() => setShowForm(p => !p)}
          className="text-xs bg-white/5 text-slate-200 border border-white/10 py-1.5 px-3 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Note</span>
        </button>
      </div>

      {/* Note draft form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2.5 font-sans">
          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-1">Title</label>
            <input
              type="text"
              placeholder="Keep Note Title"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg px-2.5 py-1 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-1">Content</label>
            <textarea
              required
              placeholder="Jot down notes or checklists..."
              value={content}
              onChange={e => setContent(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg p-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none h-20 resize-none"
            />
          </div>

          <div className="flex items-center justify-between">
            {/* Color selection row */}
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-slate-400 font-mono">Color:</span>
              <div className="flex gap-1.5">
                {['amber', 'emerald', 'sky', 'rose'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={`w-4 h-4 rounded-full border transition-all cursor-pointer ${
                      color === c ? 'ring-2 ring-indigo-500 border-white' : 'border-white/20'
                    } ${
                      c === 'amber' ? 'bg-amber-500' : c === 'emerald' ? 'bg-emerald-500' : c === 'sky' ? 'bg-sky-500' : 'bg-rose-500'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-2 py-1 hover:bg-white/10 rounded-md text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded-lg text-xs cursor-pointer shadow-md shadow-indigo-600/20"
              >
                Create
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Grid of sticky notes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[300px] overflow-y-auto pr-1">
        {notes.length === 0 ? (
          <div className="col-span-2 text-center py-10 text-slate-500">
            <p className="text-xs">No active notes pinned</p>
          </div>
        ) : (
          notes.map((note) => (
            <div
              key={note.id}
              className={`p-3 rounded-xl border flex flex-col justify-between gap-2.5 transition-all shadow-sm ${getColorClasses(note.color)}`}
            >
              <div>
                <div className="flex justify-between items-start gap-1">
                  <h4 className="text-xs font-bold leading-tight line-clamp-1">{note.title}</h4>
                  <Pin className="w-3 h-3 opacity-30 rotate-12 shrink-0" />
                </div>
                <p className="text-[10px] mt-1.5 leading-relaxed font-sans whitespace-pre-wrap">{note.content}</p>
              </div>

              <div className="flex justify-between items-center border-t border-white/10 pt-1.5 text-[9px] font-mono opacity-80">
                <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                <button
                  onClick={() => onDeleteNote(note.id)}
                  className="hover:text-red-400 opacity-60 hover:opacity-100 transition-all p-0.5 rounded cursor-pointer"
                  title="Discard Sticky Note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
