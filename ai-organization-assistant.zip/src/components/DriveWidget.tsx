import React, { useState } from 'react';
import { DriveFile } from '../types';
import { HardDrive, Search, FileText, FileSpreadsheet, PlaySquare, File, Calendar, Trash2, Plus, ArrowUpRight } from 'lucide-react';

interface DriveWidgetProps {
  files: DriveFile[];
  onCreateFile: (file: Omit<DriveFile, 'id' | 'modifiedTime' | 'size'>) => void;
  onDeleteFile: (id: string) => void;
}

export default function DriveWidget({ files, onCreateFile, onDeleteFile }: DriveWidgetProps) {
  const [filterType, setFilterType] = useState<'all' | 'document' | 'spreadsheet' | 'presentation'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<DriveFile | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [fileType, setFileType] = useState<'document' | 'spreadsheet' | 'presentation' | 'file'>('document');
  const [content, setContent] = useState('');

  const filtered = files
    .filter(f => filterType === 'all' || f.type === filterType)
    .filter(f => 
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      f.content.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    onCreateFile({
      title,
      type: fileType,
      content,
    });

    setTitle('');
    setContent('');
    setShowCreateForm(false);
  };

  const getFileIcon = (type: DriveFile['type']) => {
    switch (type) {
      case 'document':
        return <FileText className="w-4 h-4 text-blue-500" />;
      case 'spreadsheet':
        return <FileSpreadsheet className="w-4 h-4 text-emerald-500" />;
      case 'presentation':
        return <PlaySquare className="w-4 h-4 text-amber-500" />;
      default:
        return <File className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="glass-panel text-slate-100 rounded-3xl p-5 space-y-4">
      
      {/* Banner */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <HardDrive className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Google Drive Storage</h3>
            <p className="text-[10px] text-slate-450 font-mono">Workspace Storage System</p>
          </div>
        </div>

        <button
          onClick={() => setShowCreateForm(p => !p)}
          className="text-xs bg-white/5 text-slate-200 border border-white/10 py-1.5 px-3 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Document</span>
        </button>
      </div>

      {/* Query filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div className="flex bg-black/20 border border-white/5 rounded-lg p-0.5 text-[11px] font-medium text-slate-400 flex-wrap">
          {(['all', 'document', 'spreadsheet', 'presentation'] as const).map((type) => (
            <button
               key={type}
               onClick={() => { setFilterType(type); setSelectedFile(null); }}
               className={`py-1 px-2.5 rounded-md transition-colors cursor-pointer ${
                 filterType === type ? 'bg-white/10 text-white shadow-sm font-semibold' : 'hover:text-white'
               }`}
            >
              {type.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="relative text-xs">
          <input
            type="text"
            placeholder="Search Drive files..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="border border-white/10 bg-slate-900/60 rounded-lg pl-8 pr-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-full sm:w-[150px] md:w-[200px] text-white placeholder-slate-500 font-sans"
          />
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Forms creator component */}
      {showCreateForm && (
        <form onSubmit={handleCreate} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-3 font-sans">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">Title</label>
              <input
                type="text"
                required
                placeholder="Briefing Document"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full bg-slate-900/60 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">File Type</label>
              <select
                value={fileType}
                onChange={e => setFileType(e.target.value as any)}
                className="w-full bg-slate-900/80 border border-white/10 text-white rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="document">Google Doc (Document)</option>
                <option value="spreadsheet">Google Sheet (Spreadsheet)</option>
                <option value="presentation">Google Slides (Presentation)</option>
                <option value="file">Plain Text File</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">Initial Content</label>
            <textarea
              placeholder="Outline contents, data rows, or key notes..."
              value={content}
              onChange={e => setContent(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none h-20 resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 text-xs">
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className="px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3.5 py-1.5 rounded-lg text-xs cursor-pointer shadow-md shadow-indigo-600/20"
            >
              Create File
            </button>
          </div>
        </form>
      )}

      {/* Main Files Grid view */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* List Files */}
        <div className="space-y-1.5 max-h-[250px] overflow-y-auto pr-2">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <p className="text-xs">No files available</p>
            </div>
          ) : (
            filtered.map((file) => (
              <button
                key={file.id}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left p-2.5 rounded-xl border flex items-center justify-between text-xs transition-colors cursor-pointer ${
                  selectedFile?.id === file.id
                    ? 'border-indigo-500/35 bg-indigo-500/15'
                    : 'border-white/5 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2 overflow-hidden truncate">
                  {getFileIcon(file.type)}
                  <div className="truncate">
                    <p className="font-semibold text-white truncate">{file.title}</p>
                    <p className="text-[10px] text-slate-450 font-mono">
                      {new Date(file.modifiedTime).toLocaleDateString()} • {file.size}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <span className="text-[9px] font-mono capitalize bg-white/5 border border-white/5 px-1.5 py-0.5 rounded text-slate-350">
                    {file.type}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      const ok = window.confirm(`Permanently trash "${file.title}"?`);
                      if (ok) {
                        onDeleteFile(file.id);
                        if (selectedFile?.id === file.id) setSelectedFile(null);
                      }
                    }}
                    className="p-1 hover:text-red-400 text-slate-400 hover:bg-white/5 rounded transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </button>
            ))
          )}
        </div>

        {/* Selected File Contents Viewer */}
        <div className="bg-white/5 rounded-2xl border border-white/5 p-3.5 flex flex-col justify-between max-h-[250px] overflow-y-auto font-sans">
          {selectedFile ? (
            <div className="space-y-2">
              <div className="border-b border-white/10 pb-2 flex justify-between items-start gap-2">
                <div>
                  <h4 className="text-xs font-bold text-white leading-tight">{selectedFile.title}</h4>
                  <p className="text-[9px] text-slate-400 font-mono">{selectedFile.size} • Modified {new Date(selectedFile.modifiedTime).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-1 text-[10px] bg-indigo-500/20 text-indigo-200 border border-indigo-500/20 py-1 px-2 rounded-lg font-mono font-medium leading-none shrink-0">
                  <ArrowUpRight className="w-3 h-3 text-indigo-400" />
                  <span>Open</span>
                </div>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed whitespace-pre-wrap max-h-[140px] overflow-y-auto font-sans p-1">
                {selectedFile.content}
              </p>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500 flex flex-col items-center justify-center h-full">
              <FileIconPlaceholder className="w-8 h-8 text-slate-600 mb-1.5" />
              <p className="text-xs">Select any file to preview content</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}

// Simple dynamic icon representation
function FileIconPlaceholder(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth={1.5}
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"
      />
    </svg>
  );
}
