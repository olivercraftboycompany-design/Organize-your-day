import React, { useState } from 'react';
import { GoogleContact } from '../types';
import { Users, Search, Plus, Trash2, Mail, Phone, UserPlus } from 'lucide-react';

interface ContactsWidgetProps {
  contacts: GoogleContact[];
  onCreateContact: (contact: Omit<GoogleContact, 'id'>) => void;
  onDeleteContact: (id: string) => void;
}

export default function ContactsWidget({ contacts, onCreateContact, onDeleteContact }: ContactsWidgetProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  
  // Forms state
  const [givenName, setGivenName] = useState('');
  const [familyName, setFamilyName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const filtered = contacts.filter((c) => {
    const fullName = `${c.givenName} ${c.familyName}`.toLowerCase();
    const q = search.toLowerCase();
    return fullName.includes(q) || 
           c.emails.some(e => e.toLowerCase().includes(q)) ||
           c.phones.some(p => p.toLowerCase().includes(q));
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!givenName.trim() || !familyName.trim()) return;

    onCreateContact({
      givenName,
      familyName,
      emails: email ? [email.trim()] : [],
      phones: phone ? [phone.trim()] : [],
    });

    setGivenName('');
    setFamilyName('');
    setEmail('');
    setPhone('');
    setShowForm(false);
  };

  return (
    <div className="glass-panel rounded-3xl p-4 space-y-4">
      
      {/* Dynamic contacts profile banner */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <Users className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Workspace Contacts</h3>
            <p className="text-[10px] text-slate-450 font-mono">My Address Book</p>
          </div>
        </div>

        <button
          onClick={() => setShowForm(p => !p)}
          className="text-xs bg-white/5 text-slate-200 border border-white/10 py-1.5 px-3 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>New Contact</span>
        </button>
      </div>

      {/* Input query field */}
      <div className="relative text-xs">
        <input
          type="text"
          placeholder="Search corporate directory..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full border border-white/10 bg-slate-900/60 rounded-xl pl-9 pr-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-505 focus:bg-slate-900 text-white placeholder-slate-500 font-sans"
        />
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
      </div>

      {/* Contacts registration form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2.5 font-sans">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-0.5">First Name</label>
              <input
                type="text"
                required
                placeholder="E.g., Oliver"
                value={givenName}
                onChange={e => setGivenName(e.target.value)}
                className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-0.5">Last Name</label>
              <input
                type="text"
                required
                placeholder="E.g., Craft Boy"
                value={familyName}
                onChange={e => setFamilyName(e.target.value)}
                className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-0.5">Primary Email</label>
            <input
              type="email"
              placeholder="olivercraftboycompany@gmail.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase mb-0.5">Phone Number</label>
            <input
              type="text"
              placeholder="+1-555-0199"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-505 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-2 py-1.5 hover:bg-white/10 rounded-md text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-1.5 px-3 rounded-lg text-xs cursor-pointer shadow-md shadow-indigo-600/20"
            >
              Save Contact
            </button>
          </div>
        </form>
      )}

      {/* Roster profiles */}
      <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-slate-500">
            <p className="text-xs">No business profiles match</p>
          </div>
        ) : (
          filtered.map((con) => (
            <div
              key={con.id}
              className="p-3 border border-white/5 bg-white/5 rounded-xl hover:bg-white/10 transition-all flex items-center justify-between"
            >
              <div className="space-y-1 overflow-hidden">
                <p className="text-xs font-bold text-slate-100">
                  {con.givenName} {con.familyName}
                </p>
                {con.emails.length > 0 && (
                  <p className="text-[10px] text-slate-300 flex items-center gap-1 font-sans">
                    <Mail className="w-3 h-3 text-slate-500" />
                    <span>{con.emails[0]}</span>
                  </p>
                )}
                {con.phones.length > 0 && (
                  <p className="text-[10px] text-slate-300 flex items-center gap-1 font-mono">
                    <Phone className="w-2.5 h-2.5 text-slate-500" />
                    <span>{con.phones[0]}</span>
                  </p>
                )}
              </div>

              <button
                onClick={() => {
                  const del = window.confirm(`Remove workspace contact for ${con.givenName} ${con.familyName}?`);
                  if (del) onDeleteContact(con.id);
                }}
                className="text-slate-400 hover:text-red-400 p-1 rounded hover:bg-white/5 transition-colors cursor-pointer"
                title="Remove Contact profile"
              >
                <Trash2 className="w-3.5 h-3.5 shrink-0" />
              </button>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
