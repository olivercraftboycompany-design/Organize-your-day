import React, { useState } from 'react';
import { GoogleTask } from '../types';
import { CheckSquare, Square, Plus, Trash2, ListTodo, Calendar, StickyNote } from 'lucide-react';

interface TasksWidgetProps {
  tasks: GoogleTask[];
  onToggleTask: (id: string) => void;
  onCreateTask: (task: Omit<GoogleTask, 'id' | 'completed'>) => void;
  onDeleteTask: (id: string) => void;
}

export default function TasksWidget({ tasks, onToggleTask, onCreateTask, onDeleteTask }: TasksWidgetProps) {
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [dueDate, setDueDate] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onCreateTask({
      title,
      notes: notes || undefined,
      dueDate: dueDate || undefined,
    });

    setTitle('');
    setNotes('');
    setDueDate('');
    setShowForm(false);
  };

  return (
    <div className="glass-panel rounded-3xl p-5 space-y-4">
      
      {/* Title */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <ListTodo className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Google Tasks</h3>
            <p className="text-[10px] text-slate-450 font-mono">My Task Lists Sync</p>
          </div>
        </div>

        <button
          onClick={() => setShowForm(p => !p)}
          className="text-xs bg-white/5 text-slate-200 border border-white/10 py-1.5 px-3 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Task</span>
        </button>
      </div>

      {/* Task creator form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2.5 font-sans">
          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase tracking-wide mb-1">Task Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Schedule merger briefing doc"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-500 rounded-lg px-2 py-1 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase tracking-wide mb-1">Notes / Sub-tasks</label>
            <input
              type="text"
              placeholder="Conduct security analysis, gather data rows..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white placeholder-slate-500 rounded-lg px-2 py-1 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[9px] font-semibold text-slate-400 uppercase tracking-wide mb-1">Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              className="w-full bg-slate-900/60 border border-white/10 text-white rounded-lg px-2 py-1 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-2 py-1 rounded-md hover:bg-white/10 text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-1 px-3 rounded-lg text-xs cursor-pointer shadow-md shadow-indigo-600/20"
            >
              Add Task
            </button>
          </div>
        </form>
      )}

      {/* Checklist list */}
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
        {tasks.length === 0 ? (
          <div className="text-center py-10 text-slate-500">
            <p className="text-xs">No pending tasks</p>
          </div>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              className={`p-3 rounded-xl border flex items-start justify-between gap-3 transition-all ${
                task.completed 
                  ? 'bg-white/5 border-white/5 opacity-55' 
                  : 'bg-white/5 border-white/5 hover:bg-white/10'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <button
                  onClick={() => onToggleTask(task.id)}
                  className={`mt-0.5 text-slate-400 hover:text-indigo-455 transition-colors shrink-0 cursor-pointer`}
                >
                  {task.completed ? (
                    <CheckSquare className="w-4.5 h-4.5 text-indigo-400" />
                  ) : (
                    <Square className="w-4.5 h-4.5 text-slate-300 hover:text-indigo-400" />
                  )}
                </button>

                <div className="space-y-0.5">
                  <p className={`text-xs font-semibold ${task.completed ? 'line-through text-slate-450 font-medium' : 'text-white'}`}>
                    {task.title}
                  </p>
                  {task.notes && (
                    <p className="text-[10px] text-slate-300 font-sans">{task.notes}</p>
                  )}
                  {task.dueDate && (
                    <p className="text-[9px] text-indigo-300 font-mono flex items-center gap-1 mt-1 font-medium bg-indigo-500/10 border border-indigo-500/20 py-0.5 px-1.5 rounded w-max">
                      <Calendar className="w-2.5 h-2.5" />
                      Due {new Date(task.dueDate).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>

              <button
                onClick={() => onDeleteTask(task.id)}
                className="text-slate-400 hover:text-red-400 p-1 rounded hover:bg-white/5 transition-colors self-start shrink-0 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
