import React from 'react';
import { SystemLog } from '../types';
import { Calendar, Mail, HardDrive, ListTodo, StickyNote, Users, Bell, MessageSquare, Terminal } from 'lucide-react';

interface WorkspaceLogFeedProps {
  logs: SystemLog[];
  onClearLogs: () => void;
}

export default function WorkspaceLogFeed({ logs, onClearLogs }: WorkspaceLogFeedProps) {
  
  const getCategoryIcon = (category: SystemLog['category']) => {
    switch (category) {
      case 'calendar':
        return <Calendar className="w-3.5 h-3.5 text-indigo-400" />;
      case 'gmail':
        return <Mail className="w-3.5 h-3.5 text-indigo-400" />;
      case 'drive':
        return <HardDrive className="w-3.5 h-3.5 text-emerald-400" />;
      case 'tasks':
        return <ListTodo className="w-3.5 h-3.5 text-amber-400" />;
      case 'keep':
        return <StickyNote className="w-3.5 h-3.5 text-rose-400" />;
      case 'contacts':
        return <Users className="w-3.5 h-3.5 text-indigo-400" />;
      case 'chat':
        return <MessageSquare className="w-3.5 h-3.5 text-blue-400" />;
      default:
        return <Terminal className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getLogClasses = (type: SystemLog['type']) => {
    switch (type) {
      case 'success':
        return 'border-l-3 border-emerald-500/60 bg-emerald-500/5';
      case 'warning':
        return 'border-l-3 border-amber-500/60 bg-amber-500/5';
      default:
        return 'border-l-3 border-slate-500/30 bg-white/5';
    }
  };

  return (
    <div id="workspace_logs" className="glass-panel rounded-3xl p-4 space-y-4">
      
      {/* Target heading */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <Bell className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display">Simulated Google Chat Notifications</h3>
            <p className="text-[10px] text-slate-450 font-mono">Workspace Operations Ledger</p>
          </div>
        </div>

        <button
          onClick={onClearLogs}
          className="text-[10px] font-mono hover:text-red-400 text-slate-400 transition-colors cursor-pointer"
        >
          Clear Ledger
        </button>
      </div>

      {/* Log Feed */}
      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
        {logs.length === 0 ? (
          <div className="text-center py-10 text-slate-505">
            <p className="text-xs">Ledger is empty</p>
          </div>
        ) : (
          logs.map((log) => (
            <div
              key={log.id}
              className={`p-2.5 rounded-lg flex items-start gap-2 text-xs transition-all ${getLogClasses(log.type)}`}
            >
              <div className="mt-0.5 shrink-0 bg-slate-900 p-1 rounded-md border border-white/5 shadow-xs">
                {getCategoryIcon(log.category)}
              </div>
              
              <div className="space-y-0.5 flex-1">
                <p className="text-slate-200 leading-normal font-sans">{log.message}</p>
                <div className="flex items-center gap-1.5 text-[9px] font-mono text-slate-450">
                  <span className="capitalize">{log.category} update</span>
                  <span>•</span>
                  <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
