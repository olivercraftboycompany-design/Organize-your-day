import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with key from environment variables
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey) {
  ai = new GoogleGenAI({ apiKey: geminiApiKey });
  console.log('Gemini API initialized successfully.');
} else {
  console.warn('WARNING: GEMINI_API_KEY is not set. Chat features will fall back to mock coordination.');
}

// Coordinate the AI Assistant queries
app.post('/api/agent/chat', async (req, res) => {
  try {
    const { messages, selectedModel, useThinking, webGrounding, localTime } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    // Determine target model
    // Users can choose gemini-3.1-pro-preview (complex / thinking), gemini-3.5-flash (general), or gemini-3.1-flash-lite (fast)
    // We fall back to robust defaults if the API doesn't support them directly
    let targetModel = 'gemini-2.5-flash';
    if (selectedModel) {
      if (selectedModel.includes('3.5-flash')) {
        targetModel = 'gemini-2.5-flash'; // Fallback to 2.5-flash or use requested literal
      } else if (selectedModel.includes('3.2') || selectedModel.includes('3.1-pro')) {
        targetModel = 'gemini-2.5-pro';
      } else if (selectedModel.includes('3.1-flash-lite')) {
        targetModel = 'gemini-1.5-flash';
      } else {
        targetModel = selectedModel;
      }
    }

    const systemInstruction = `You are the executive mastermind "AI Organization Assistant" with full operational dashboard capabilities.
You have the ability to read and write Google Workspace products on behalf of the user with their explicitly approved scopes, including Google Calendar, Gmail, Google Drive, Google Sheets, Google Docs, Google Slides, Google Tasks, Google Keep, Google Chat, Google Meet, and Contacts.

Current Local Time is: ${localTime || new Date().toISOString()}

Your task:
1. Analyze the user's natural language request.
2. Formulate helpful commentary for the user.
3. Propose zero or more workspace actions that represent what needs to be created, read, updated, or scheduled.
4. Return your response ONLY as a JSON object adhering STRICTLY to this JSON schema:
{
  "text": "A friendly conversational explanation of what you can do is here.",
  "proposedActions": [
    {
      "id": "uniquely_generated_id",
      "type": "calendar_create" | "calendar_delete" | "gmail_send" | "drive_create_file" | "drive_delete_file" | "tasks_create" | "tasks_update" | "keep_create" | "keep_delete" | "sheets_append" | "contacts_create" | "chat_send_message",
      "description": "Short legible description of the specific proposal",
      "params": {
        // for calendar_create: summary (string), description (string), startTime (ISO string), endTime (ISO string), attendees (string[]), addMeetLink (boolean)
        // for calendar_delete: eventId (string)
        // for gmail_send: recipient (string), subject (string), body (string)
        // for drive_create_file: title (string), type ( 'document' | 'spreadsheet' | 'presentation' | 'file' ), content (string)
        // for drive_delete_file: fileId (string)
        // for tasks_create: title (string), notes (string), dueDate (ISO string option)
        // for tasks_update: taskId (string), completed (boolean)
        // for keep_create: title (string), content (string), color (string like 'blue' | 'yellow' | 'red')
        // for keep_delete: noteId (string)
        // for sheets_append: spreadsheetId (string option), sheetName (string option), rowValues (array of string/number values)
        // for contacts_create: givenName (string), familyName (string), emails (string[]), phones (string[])
        // for chat_send_message: spaceId (string option), message (string)
      }
    }
  ]
}

CRITICAL RULES:
- IMPORTANT: When writing email or document body material, craft rich, complete, professional drafts that fit the user context. Do not write lazy placeholders like "insert text here".
- DO NOT wrap the json in any markdown blocks (\`\`\`json ...) or output any extra characters. Return only the parsable JSON string.
- Keep the tone highly intelligent, composed, professional, and humble.
- Only propose actions that are explicitly requested or directly necessary to fulfill the user request.
`;

    if (!ai) {
      // Offline fallback mock responses for testing/sandboxed mode without GEMINI_API_KEY
      return res.json(simulateResponse(messages, systemInstruction));
    }

    // Configure request options
    const contents: any[] = [];
    messages.forEach(msg => {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      });
    });

    const config: any = {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.1,
    };

    if (useThinking) {
      config.thinkingConfig = {
        thinkingBudget: 1024
      };
    }

    if (webGrounding) {
      config.tools = [{ googleSearch: {} }];
    }

    try {
      const response = await ai.models.generateContent({
        model: targetModel,
        contents,
        config
      });

      const responseText = response.text || '';
      const parsed = JSON.parse(responseText.trim());
      return res.json(parsed);
    } catch (apiErr: any) {
      console.error('Gemini API call failed, falling back to simulation:', apiErr);
      return res.json(simulateResponse(messages, systemInstruction));
    }

  } catch (err: any) {
    console.error('Server error handling chat:', err);
    res.status(500).json({ error: 'Internal server error', details: err.message });
  }
});

// Mock simulation of Gemini actions to cover demo and missing API Key gracefully
function simulateResponse(messages: any[], systemInstruction: string) {
  const lastUserMsg = [...messages].reverse().find(m => m.role === 'user')?.content || '';
  const textLower = lastUserMsg.toLowerCase();
  
  let responseText = "I have analyzed your request. I can propose the following workspace enhancements.";
  const proposedActions: any[] = [];

  if (textLower.includes('meeting') || textLower.includes('schedule') || textLower.includes('calendar') || textLower.includes('sync')) {
    const titleMatch = lastUserMsg.match(/(?:called|about|titled)\s+["']?([^"']+)["']?/i);
    const title = titleMatch ? titleMatch[1] : 'Workspace Synchronization';
    
    proposedActions.push({
      id: `sim_cal_${Date.now()}`,
      type: 'calendar_create',
      description: `Schedule calendar event: "${title}"`,
      params: {
        summary: title,
        description: 'Scheduled via AI Organization Assistant. Google Meet link integrated.',
        startTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0] + 'T14:00:00',
        endTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0] + 'T15:00:00',
        attendees: ['olivercraftboycompany@gmail.com'],
        addMeetLink: true
      }
    });
    responseText = "Certainly. I would like to schedule this workspace meeting for you and append an official Google Meet room.";
  } else if (textLower.includes('email') || textLower.includes('gmail') || textLower.includes('draft') || textLower.includes('send')) {
    const emailMatch = lastUserMsg.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/);
    const recipient = emailMatch ? emailMatch[1] : 'olivercraftboycompany@gmail.com';
    
    proposedActions.push({
      id: `sim_mail_${Date.now()}`,
      type: 'gmail_send',
      description: `Draft and send Gmail message to ${recipient}`,
      params: {
        recipient,
        subject: 'Inquiry: Workspace Coordination Update',
        body: 'Warm greetings,\n\nThis communication is an automated sync compiled of current organizational tasks and calendar deadlines.\n\nWarm regards,\nAdministrative Assistant'
      }
    });
    responseText = `I have drafted an email for you targeted to ${recipient}. Please confirm to send it securely.`;
  } else if (textLower.includes('document') || textLower.includes('slide') || textLower.includes('drive') || textLower.includes('create doc') || textLower.includes('doc')) {
    let type = 'document';
    if (textLower.includes('slide') || textLower.includes('presentation')) type = 'presentation';
    if (textLower.includes('sheet') || textLower.includes('spreadsheet')) type = 'spreadsheet';

    proposedActions.push({
      id: `sim_drive_${Date.now()}`,
      type: 'drive_create_file',
      description: `Generate Google Drive ${type}: "Organisational Architecture Brief"`,
      params: {
        title: 'Organisational Architecture Brief',
        type,
        content: '# AI Workspace Intelligence Outline\nThis slide presentation / briefing document establishes corporate organizational structures.'
      }
    });
    responseText = `Excellent. I can construct a customized Google Drive ${type} containing clean business structures.`;
  } else if (textLower.includes('task') || textLower.includes('todo') || textLower.includes('to-do')) {
    proposedActions.push({
      id: `sim_task_${Date.now()}`,
      type: 'tasks_create',
      description: 'Create task: "Review newly provisioned Google Workspace connections"',
      params: {
        title: 'Review newly provisioned Google Workspace connections',
        notes: 'Conduct rigorous integration testing on Contacts, Keep, Calendar, and Mail endpoints.',
        dueDate: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString()
      }
    });
    responseText = 'I have analyzed your request and formulated a high-priority work task for Gmail/Tasks integration.';
  } else if (textLower.includes('keep') || textLower.includes('note')) {
    proposedActions.push({
      id: `sim_keep_${Date.now()}`,
      type: 'keep_create',
      description: 'Push new Google Keep Note containing meeting ideas',
      params: {
        title: 'Weekly Sprint Strategy Notes',
        content: 'Focus points:\n- Workspace OAuth stabilization\n- Local storage fail-safes\n- Gemini integration rules',
        color: 'yellow'
      }
    });
    responseText = 'Reviewing your concepts, I can create an organized Yellow Visual Sticky Note in Google Keep.';
  } else if (textLower.includes('contact') || textLower.includes('people') || textLower.includes('add contact')) {
    proposedActions.push({
      id: `sim_contact_${Date.now()}`,
      type: 'contacts_create',
      description: 'Register Google Contact: "Oliver Craft Boy"',
      params: {
        givenName: 'Oliver',
        familyName: 'Craft Boy',
        emails: ['olivercraftboycompany@gmail.com'],
        phones: ['+1-555-0192']
      }
    });
    responseText = 'I have compiled contact records and prepared a registration block for Google Contacts card synchronization.';
  } else {
    // General chat response
    responseText = "Hello. I am your Google Workspace AI Administration Specialist. Tell me if you'd like to schedule events, construct documents, draft emails, create tasks, list files, append spreadsheets, or synchronize contacts.";
  }

  return { text: responseText, proposedActions };
}

// Vite static dev integration or Production server
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Organization Server booted on http://0.0.0.0:${PORT}`);
  });
}

start();
